from django.apps import AppConfig


class TasktrackerConfig(AppConfig):
    name = 'tasktracker'
