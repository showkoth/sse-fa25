# Vulnerable Dependency Finder

A Python-based tool for detecting known security vulnerabilities in Java Maven dependencies by analyzing POM.xml files against the National Vulnerability Database (NVD).

## Installation

1. Ensure Python 3.8+ is installed
2. Install required dependencies:
   ```bash
   pip3 install -r requirements.txt
   ```

## Running the program

### Reload and Detect Mode

Reloads the vulnerability database from NVD, then analyzes the POM file:

```bash
python3 main.py all sample-pom-files/pom-2.xml
```
### Detect Mode (Query Only)

Analyzes a POM file using the existing vulnerability database:

```bash
python3 main.py detect sample-pom-files/pom-2.xml
```

**Note**: The database file  (`vulnerabilities.sqlite`) is excluded from git due to its large size (552 MB). It will be automatically created on first run. If dataset is missing, please run the program in given order (reload and detect mode first) so that the program can download the required dataset.