"""
POM Parser for Maven Project Files
Extracts dependency information from Maven POM.xml files.
"""

import xml.etree.ElementTree as ET
from typing import List, Dict


class PomParser:
    """Parser for Maven POM.xml files to extract dependency information."""
    
    def __init__(self):
        """Initialize the POM parser."""
        self.namespace = {'m': 'http://maven.apache.org/POM/4.0.0'}
    
    def parse_dependencies(self, pom_file_path: str) -> List[Dict[str, str]]:
        """Parse dependencies from a POM file.
        
        Args:
            pom_file_path: Path to the POM.xml file
            
        Returns:
            List of dependency dictionaries with groupId, artifactId, and version
        """
        dependencies = []
        
        try:
            tree = ET.parse(pom_file_path)
            root = tree.getroot()
            
            # Handle namespace-aware parsing
            namespace = self._get_namespace(root)
            
            # Find all dependency elements
            dependency_elements = root.findall('.//dependency', namespace)
            
            for dep in dependency_elements:
                group_id = self._get_element_text(dep, 'groupId', namespace)
                artifact_id = self._get_element_text(dep, 'artifactId', namespace)
                version = self._get_element_text(dep, 'version', namespace)
                scope = self._get_element_text(dep, 'scope', namespace)
                
                # Only include dependencies with all required fields
                if group_id and artifact_id and version:
                    dependencies.append({
                        'groupId': group_id,
                        'artifactId': artifact_id,
                        'version': version,
                        'scope': scope or 'compile'
                    })
        
        except ET.ParseError as e:
            raise ValueError(f"Error parsing POM file: {e}")
        except FileNotFoundError:
            raise FileNotFoundError(f"POM file not found: {pom_file_path}")
        
        return dependencies
    
    def _get_namespace(self, root: ET.Element) -> Dict[str, str]:
        """Extract namespace from the root element.
        
        Args:
            root: Root XML element
            
        Returns:
            Namespace dictionary for XML parsing
        """
        if root.tag.startswith('{'):
            # Extract namespace from tag
            namespace_uri = root.tag[1:root.tag.find('}')]
            return {'': namespace_uri}
        return {}
    
    def _get_element_text(self, parent: ET.Element, tag_name: str, namespace: Dict[str, str]) -> str:
        """Get text content of a child element.
        
        Args:
            parent: Parent XML element
            tag_name: Name of the child element
            namespace: XML namespace dictionary
            
        Returns:
            Text content of the element, or empty string if not found
        """
        if namespace:
            element = parent.find(tag_name, namespace)
        else:
            element = parent.find(tag_name)
        
        return element.text.strip() if element is not None and element.text else ""
    
    def validate_pom_file(self, pom_file_path: str) -> bool:
        """Validate if the file is a valid POM file.
        
        Args:
            pom_file_path: Path to the POM file
            
        Returns:
            True if valid POM file, False otherwise
        """
        try:
            tree = ET.parse(pom_file_path)
            root = tree.getroot()
            
            # Check if it's a Maven POM file
            if 'project' in root.tag.lower():
                return True
            
        except ET.ParseError:
            pass
        
        return False
