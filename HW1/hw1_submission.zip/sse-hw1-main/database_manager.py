"""
Database Manager for NVD CVE Data
Handles SQLite database operations for storing and querying vulnerability data.
"""

import sqlite3
import json
import requests
import gzip
import tempfile
from typing import List, Dict, Any


class DatabaseManager:
    """Manages the SQLite database for CVE data storage and retrieval."""
    
    def __init__(self, db_path: str):
        """Initialize the database manager.
        
        Args:
            db_path: Path to the SQLite database file
        """
        self.db_path = db_path
        self.connection = None
        self._setup_database()
    
    def _setup_database(self):
        """Create database tables if they don't exist."""
        self.connection = sqlite3.connect(self.db_path)
        self.connection.execute('PRAGMA foreign_keys = ON')
        
        # Create tables
        self.connection.executescript('''
            CREATE TABLE IF NOT EXISTS cves (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cve_id TEXT UNIQUE NOT NULL,
                description TEXT,
                published_date TEXT,
                modified_date TEXT,
                severity TEXT
            );
            
            CREATE TABLE IF NOT EXISTS cpe_matches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cve_id TEXT NOT NULL,
                cpe23_uri TEXT NOT NULL,
                vendor TEXT,
                product TEXT,
                version_start_excluding TEXT,
                version_start_including TEXT,
                version_end_excluding TEXT,
                version_end_including TEXT,
                vulnerable BOOLEAN DEFAULT TRUE,
                FOREIGN KEY (cve_id) REFERENCES cves(cve_id)
            );
            
            CREATE INDEX IF NOT EXISTS idx_cve_id ON cpe_matches(cve_id);
            CREATE INDEX IF NOT EXISTS idx_vendor_product ON cpe_matches(vendor, product);
        ''')
        self.connection.commit()
    
    def reload_database(self):
        """Reload the database with fresh CVE data from NVD."""
        # Clear existing data
        self.connection.execute('DELETE FROM cpe_matches')
        self.connection.execute('DELETE FROM cves')
        self.connection.commit()
        
        # Load fresh data
        self._load_nvd_data()
    
    def _load_nvd_data(self):
        """Load CVE data from NVD JSON feeds."""
        start_year = 2015
        end_year = 2024
        years = list(range(start_year, end_year + 1))  # 2015 through 2024

        for year in years:
            print(f"Loading CVE data for year {year}...")
            self._load_year_data(year)
    
    def _load_year_data(self, year: int):
        """Load CVE data for a specific year.
        
        Args:
            year: The year to load data for
        """
        url = f"https://nvd.nist.gov/feeds/json/cve/2.0/nvdcve-2.0-{year}.json.gz"
        
        try:
            response = requests.get(url, timeout=60)
            response.raise_for_status()
            
            with tempfile.TemporaryFile() as temp:
                temp.write(response.content)
                temp.seek(0)
                
                with gzip.open(temp, 'rb') as f:
                    data = json.loads(f.read().decode('utf-8'))
                    self._process_cve_data(data)
                    
        except Exception as e:
            print(f"Error loading data for year {year}: {e}")
    
    def _process_cve_data(self, data: Dict[str, Any]):
        """Process CVE data and store in database.
        
        Args:
            data: The parsed JSON data from NVD
        """
        if 'vulnerabilities' not in data:
            return
            
        cve_batch = []
        cpe_batch = []
        
        for entry in data['vulnerabilities']:
            cve = entry.get('cve', {})
            cve_id = cve.get('id', '')
            
            if not cve_id:
                continue
            
            # Extract description
            descriptions = cve.get('descriptions', [])
            description = ""
            for desc in descriptions:
                if desc.get('lang') == 'en':
                    description = desc.get('value', '')
                    break
            
            # Extract dates
            published_date = cve.get('published', '')
            modified_date = cve.get('lastModified', '')
            
            # Extract severity (from CVSS metrics)
            severity = self._extract_severity(cve)
            
            # Store CVE
            cve_batch.append((cve_id, description, published_date, modified_date, severity))
            
            # Process configurations
            if 'configurations' in cve:
                for config in cve['configurations']:
                    for node in config.get('nodes', []):
                        for cpe_match in node.get('cpeMatch', []):
                            cpe_data = self._parse_cpe_match(cve_id, cpe_match)
                            if cpe_data:
                                cpe_batch.append(cpe_data)
        
        # Batch insert
        self.connection.executemany('''
            INSERT OR REPLACE INTO cves 
            (cve_id, description, published_date, modified_date, severity)
            VALUES (?, ?, ?, ?, ?)
        ''', cve_batch)
        
        self.connection.executemany('''
            INSERT INTO cpe_matches 
            (cve_id, cpe23_uri, vendor, product, version_start_excluding, 
             version_start_including, version_end_excluding, version_end_including, vulnerable)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', cpe_batch)
        
        self.connection.commit()
        print(f"Processed {len(cve_batch)} CVEs with {len(cpe_batch)} CPE matches")
    
    def _extract_severity(self, cve: Dict[str, Any]) -> str:
        """Extract severity from CVE metrics.
        
        Args:
            cve: CVE data dictionary
            
        Returns:
            Severity level as string
        """
        metrics = cve.get('metrics', {})
        
        # Try CVSS v3.1 first
        if 'cvssMetricV31' in metrics:
            for metric in metrics['cvssMetricV31']:
                cvss_data = metric.get('cvssData', {})
                return cvss_data.get('baseSeverity', 'Unknown')
        
        # Try CVSS v3.0
        if 'cvssMetricV30' in metrics:
            for metric in metrics['cvssMetricV30']:
                cvss_data = metric.get('cvssData', {})
                return cvss_data.get('baseSeverity', 'Unknown')
        
        # Try CVSS v2
        if 'cvssMetricV2' in metrics:
            for metric in metrics['cvssMetricV2']:
                cvss_data = metric.get('cvssData', {})
                base_score = cvss_data.get('baseScore', 0)
                if base_score >= 7.0:
                    return 'High'
                elif base_score >= 4.0:
                    return 'Medium'
                else:
                    return 'Low'
        
        return 'Unknown'
    
    def _parse_cpe_match(self, cve_id: str, cpe_match: Dict[str, Any]) -> tuple:
        """Parse CPE match data.
        
        Args:
            cve_id: CVE identifier
            cpe_match: CPE match data
            
        Returns:
            Tuple of CPE data for database insertion
        """
        cpe23_uri = cpe_match.get('criteria', '')
        vulnerable = cpe_match.get('vulnerable', True)
        
        # Parse CPE URI to extract vendor and product
        vendor, product = self._parse_cpe_uri(cpe23_uri)
        
        version_start_excluding = cpe_match.get('versionStartExcluding')
        version_start_including = cpe_match.get('versionStartIncluding')
        version_end_excluding = cpe_match.get('versionEndExcluding')
        version_end_including = cpe_match.get('versionEndIncluding')
        
        return (cve_id, cpe23_uri, vendor, product, 
                version_start_excluding, version_start_including,
                version_end_excluding, version_end_including, vulnerable)
    
    def _parse_cpe_uri(self, cpe_uri: str) -> tuple:
        """Parse CPE URI to extract vendor and product.
        
        Args:
            cpe_uri: CPE 2.3 URI
            
        Returns:
            Tuple of (vendor, product)
        """
        if not cpe_uri.startswith('cpe:2.3:'):
            return None, None
        
        parts = cpe_uri.split(':')
        if len(parts) < 5:
            return None, None
        
        vendor = parts[3] if parts[3] != '*' else None
        product = parts[4] if parts[4] != '*' else None
        
        return vendor, product
    
    def search_vulnerabilities(self, group_id: str, artifact_id: str, version: str) -> List[Dict[str, Any]]:
        """Search for vulnerabilities matching the given dependency.
        
        Args:
            group_id: Maven group ID
            artifact_id: Maven artifact ID
            version: Dependency version
            
        Returns:
            List of matching vulnerabilities
        """
        cursor = self.connection.cursor()
        
        # Search with exact match first
        exact_query = '''
            SELECT DISTINCT c.cve_id, c.description, c.severity, cm.cpe23_uri
            FROM cves c
            JOIN cpe_matches cm ON c.cve_id = cm.cve_id
            WHERE cm.vulnerable = 1 
            AND (cm.vendor = ? OR cm.product = ?)
        '''
        
        cursor.execute(exact_query, (group_id, artifact_id))
        exact_results = cursor.fetchall()
        
        if exact_results:
            return self._format_vulnerability_results(exact_results)
        
        # Try fuzzy matching
        fuzzy_query = '''
            SELECT DISTINCT c.cve_id, c.description, c.severity, cm.cpe23_uri, cm.vendor, cm.product
            FROM cves c
            JOIN cpe_matches cm ON c.cve_id = cm.cve_id
            WHERE cm.vulnerable = 1 
            AND cm.vendor IS NOT NULL 
            AND cm.product IS NOT NULL
        '''
        
        cursor.execute(fuzzy_query)
        all_results = cursor.fetchall()
        
        # Apply fuzzy matching
        from Levenshtein import distance
        
        matches = []
        for result in all_results:
            cve_id, description, severity, cpe_uri, vendor, product = result
            
            # Calculate Levenshtein distance
            vendor_dist = distance(group_id.lower(), vendor.lower()) if vendor else float('inf')
            product_dist = distance(artifact_id.lower(), product.lower()) if product else float('inf')
            
            # Use threshold of 3 for matching
            if vendor_dist <= 3 and product_dist <= 3:
                matches.append((cve_id, description, severity, cpe_uri))
        
        return self._format_vulnerability_results(matches)
    
    def _format_vulnerability_results(self, results: List[tuple]) -> List[Dict[str, Any]]:
        """Format vulnerability results into a structured format.
        
        Args:
            results: Raw database results
            
        Returns:
            Formatted vulnerability data
        """
        formatted = []
        for result in results:
            cve_id, description, severity, cpe_uri = result
            formatted.append({
                'id': cve_id,
                'description': description,
                'severity': severity or 'Unknown',
                'cpe_uri': cpe_uri
            })
        return formatted
    
    def get_database_stats(self) -> Dict[str, int]:
        """Get basic statistics about the database.
        
        Returns:
            Dictionary with database statistics
        """
        cursor = self.connection.cursor()
        
        cursor.execute('SELECT COUNT(*) FROM cves')
        cve_count = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM cpe_matches')
        cpe_count = cursor.fetchone()[0]
        
        return {
            'total_cves': cve_count,
            'total_cpe_matches': cpe_count
        }
    
    def close(self):
        """Close the database connection."""
        if self.connection:
            self.connection.close()
