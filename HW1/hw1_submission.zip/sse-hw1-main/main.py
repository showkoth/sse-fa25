#!/usr/bin/env python3
"""
Vulnerable Dependency Finder for Java Programs
SSE FA25 - Homework 1

Author: [Showkot Hossain]
Date: September 2025
"""

import sys
import argparse
from pathlib import Path
from database_manager import DatabaseManager
from pom_parser import PomParser
from vulnerability_detector import VulnerabilityDetector


def main():
    """Main entry point for the vulnerable dependency finder."""
    parser = argparse.ArgumentParser(description='Vulnerable Dependency Finder for Java Programs')
    parser.add_argument('mode', choices=['detect', 'all'], 
                       help='Execution mode: detect (query only) or all (reload then detect)')
    parser.add_argument('pom_file', help='Path to the POM file to analyze')
    
    args = parser.parse_args()
    
    # Validate POM file exists
    pom_path = Path(args.pom_file)
    if not pom_path.exists():
        print(f"Error: POM file '{args.pom_file}' not found.")
        sys.exit(1)
    
    try:
        # Initialize components
        db_manager = DatabaseManager('vulnerabilities.sqlite')
        pom_parser = PomParser()
        detector = VulnerabilityDetector(db_manager)
        
        # Handle execution modes
        if args.mode == 'all':
            print("Reloading vulnerability database from NVD...")
            db_manager.reload_database()
            print("Database reloaded successfully.")
        
        # Parse POM file to extract dependencies
        print(f"Parsing POM file: {args.pom_file}")
        dependencies = pom_parser.parse_dependencies(args.pom_file)
        print(f"Found {len(dependencies)} dependencies.")
        
        # Detect vulnerabilities
        print("Checking for vulnerabilities...")
        print("Be patient...")
        print("This may take a while depending on the number of dependencies and database size.")
        vulnerabilities = detector.detect_vulnerabilities(dependencies)
        
        # Generate output
        output_file = 'result.txt'
        generate_output(vulnerabilities, output_file)
        print(f"Results written to {output_file}")
        
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


def generate_output(vulnerabilities, output_file):
    """Generate the output file with vulnerability results."""
    with open(output_file, 'w', encoding='utf-8') as f:
        if not vulnerabilities:
            f.write("No vulnerability found\n")
        else:
            f.write("Known security vulnerabilities detected:\n\n")
            for vuln in vulnerabilities:
                f.write(f"Dependency: {vuln['artifact_id']}\n")
                f.write(f"Version(s): {vuln['version']}\n")
                f.write("Vulnerabilities:\n")
                for cve in vuln['cves']:
                    severity = cve.get('severity', 'Unknown')
                    f.write(f"- {cve['id']} ({severity} severity)\n")
                f.write("\n")


if __name__ == "__main__":
    main()
