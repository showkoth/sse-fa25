# Password Cracker - HW2 Part 3

## How to Run

```bash
python3 password_cracker.py
```

## What it does

- Cracks MD5 hashes from 3 files (90 passwords total)
- Uses brute force attack (3-6 character passwords)
- Saves results to `cracked_passwords.txt`
- Target: Find 60+ passwords
